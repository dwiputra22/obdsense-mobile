import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin =
  FlutterLocalNotificationsPlugin();

  Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');

    const iOS = DarwinInitializationSettings(
      requestAlertPermission: true,
      requestBadgePermission: true,
      requestSoundPermission: true,
    );

    const settings = InitializationSettings(android: android, iOS: iOS);
    await _plugin.initialize(settings);
  }

  Future<void> showHighTempAlert(double tempC) async {
    const androidDetails = AndroidNotificationDetails(
      'high_temp_channel',
      'High Temperature Alerts',
      channelDescription: 'Peringatan suhu mesin tinggi',
      importance: Importance.max,
      priority: Priority.high,
    );

    const iosDetails = DarwinNotificationDetails(
      presentAlert: true,
      presentBadge: true,
      presentSound: true,
    );

    const details = NotificationDetails(android: androidDetails, iOS: iosDetails);

    await _plugin.show(
      1001,
      'Suhu Mesin Tinggi',
      'Suhu mesin terdeteksi ${tempC.toStringAsFixed(0)}°C. Segera pantau kondisi kendaraan.',
      details,
    );
  }
}
