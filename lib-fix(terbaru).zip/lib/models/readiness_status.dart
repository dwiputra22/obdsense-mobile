class ReadinessMonitor {
  final String name;
  final bool supported;
  final bool ready;

  const ReadinessMonitor({
    required this.name,
    required this.supported,
    required this.ready,
  });
}

/// Status monitor kesiapan emisi (Readiness) - hasil decode PID 0101.
/// Penting untuk lolos uji emisi: kalau ada monitor yang "Belum Siap",
/// artinya self-test terkait belum selesai dijalankan ECU sejak kode
/// error terakhir dihapus (mis. abis clear DTC, abis lepas aki) - mobil
/// perlu dikendarai dengan pola tertentu (drive cycle) dulu supaya semua
/// monitor selesai sebelum uji emisi.
class ReadinessStatus {
  final bool milOn;
  final int dtcCount;
  final bool isCompressionIgnition; // false = bensin (spark), true = diesel
  final List<ReadinessMonitor> monitors;

  const ReadinessStatus({
    required this.milOn,
    required this.dtcCount,
    required this.isCompressionIgnition,
    required this.monitors,
  });

  bool get allReady => monitors.where((m) => m.supported).every((m) => m.ready);
}
