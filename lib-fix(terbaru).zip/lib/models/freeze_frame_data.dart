/// Snapshot nilai sensor PERSIS saat sebuah DTC terpicu (Mode 02) -
/// beda dari data live (Mode 01) yang menunjukkan kondisi SEKARANG.
/// Berguna untuk diagnosa: "RPM berapa, kecepatan berapa, suhu berapa
/// saat kode error ini muncul" - bukan cuma tahu ADA error, tapi tahu
/// KONDISI mobil saat itu terjadi.
class FreezeFrameData {
  final String triggeringDtc;
  final double? rpm;
  final double? speed;
  final double? coolantTempC;
  final double? engineLoad;
  final double? throttlePosition;
  final double? intakeTempC;
  final double? fuelLevelPercent;

  const FreezeFrameData({
    required this.triggeringDtc,
    this.rpm,
    this.speed,
    this.coolantTempC,
    this.engineLoad,
    this.throttlePosition,
    this.intakeTempC,
    this.fuelLevelPercent,
  });
}
