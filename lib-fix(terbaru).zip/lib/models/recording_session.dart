import 'telemetry_data.dart';

/// Sesi rekaman mentah semua sensor OBD - beda dari TripRecord (yang
/// menyimpan RINGKASAN statistik trip). Ini menyimpan SETIAP sample
/// mentah, untuk analisa diagnostik detail atau diekspor ke CSV.
class RecordingSession {
  final DateTime startedAt;
  final DateTime endedAt;
  final List<TelemetryData> samples;

  const RecordingSession({
    required this.startedAt,
    required this.endedAt,
    required this.samples,
  });
}
